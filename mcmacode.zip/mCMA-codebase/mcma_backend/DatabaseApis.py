import pandas as pd
import random
import pycountry as pc
import json
import string

def dictCountries():
        df = pd.DataFrame(columns = ['name'])
        for i  in range(len(list(pc.countries))):
                df.loc[i,'name'] = str(list(pc.countries)[i].name)
        return df
    


def retrieveData(customer_users):
    customer_list=[]
    for x in customer_users.find({},{"_id": 0, "customer_id": 1,"email":1, "customer_name": 1 ,"city":1,"country":1}):
        customer_list.append(x)
    return(customer_list)
    
def retrieveAdmin(customer_users):
    listall=[]
    for x in customer_users.find({"role":"admin"},{ "_id": 0, "customer_id": 1,"email":1, "customer_name": 1 ,"city":1,"country":1}):
        listall.append(x)
    return(listall)
    


def randomString(stringLength=5):
    """Generate a random string of fixed length """
    letters = string.ascii_lowercase
    return ''.join(random.choice(letters) for i in range(stringLength))
def randomCustomer():
    customer_id=random.randint(10000,99999)
    return(customer_id)

def randomAssessment():
    random_values=random.randint(10,9999)
    values=str(random_values)
    return("assessment"+values)