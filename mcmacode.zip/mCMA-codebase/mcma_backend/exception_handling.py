# -*- coding: utf-8 -*-
"""
Created on Fri Jul 12 13:19:14 2019

@author: Ullash.Srivastava
"""

import pandas as pd
import numpy as np
from custom_exceptions import (ColumnsIdMismatch, RowsIdMismatch, InvalidClassId,
                                InvalidCategoryId,EmptyDataFrameException)


def validate_data(data):
    columns=list(data.columns)
    columns.append(data.index.name)
    rows=[]
    if not (set(['Question','YES','NO','Category','Type','Link','Q.id']).issubset(set(columns))):
        raise ColumnsIdMismatch()
    categories=list(data["Category"].unique())

    input_type=list(data["Type"].unique())
    if not (set(input_type).issubset(set(['scoring','conditional','text']))):
        raise InvalidClassId()
    for i in list(data.index):
        rows.append(i.split('_')[0])
    x = np.unique(np.array(rows))
    if not (set(x)).issubset(set(['ques'])):
        raise RowsIdMismatch()
    if not (set(categories)).issubset(set(['GO/No GO','COTS','Remediation Type'])):
        raise InvalidCategoryId()  
    
    if data.empty:
        raise EmptyDataFrameException()
    return data