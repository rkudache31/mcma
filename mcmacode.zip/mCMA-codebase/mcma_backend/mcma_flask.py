# -*- coding: utf-8 -*-
"""
Created on Tue Aug 27 06:15:15 2019

@author: Administrator
"""

import pymongo
from flask import Flask, request,jsonify
from flask_cors import CORS
import json
import pandas as pd
from bson import json_util, ObjectId
import random
import string
import smtplib, ssl
import socket
import flask
from flask_mail import Mail, Message
import numpy as np
import pycountry as pc
import exception_handling as EH
from custom_exceptions import (ColumnsIdMismatch, RowsIdMismatch, InvalidClassId,
                                InvalidCategoryId,EmptyDataFrameException)

from DatabaseApis import (dictCountries,retrieveData,retrieveAdmin, randomString,randomCustomer,randomAssessment)
from PerformingAssessment import application_assessment
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import smtplib

myclient = pymongo.MongoClient("mongodb://18.219.123.141:27017/")
db = myclient['x2c2']
customer_users = db["x2c2_customer"]
assessment=db["x2c2_assessments"]
user_applications=db["x2c2_applications"]
recommendations=db["recommendations_type"]

recommendation_data=pd.read_csv("recommendation.csv")
recommendation_data_dict=recommendation_data.to_dict('list')
recommendation_json={}
recommendation_json["recommendations"]=recommendation_data_dict
recommendation_json["version"]="v1"
recommendations.insert_one(recommendation_json)
#if(recommendations.find_one({"version":"v1"})):
#    print("Print Document already exists")
#    
x=recommendations.find_one({"version":"v1"})
if(x):
    print("document exists")
else:
    recommendations.insert_one(recommendation_json)
    print("document uploaded")

    
    
app = Flask(__name__)
CORS(app)

#-------------Get countr----------
    
@app.route('/getcountries', methods = ['GET'])
def getCountry():
    data=dictCountries()    
    countries=data["name"].tolist()
    return jsonify({"countries":countries})
        
    
#----------check username------------------
@app.route('/checkUsername/<email_id>', methods = ['GET','POST'])
def check_user(email_id):
    email_id=email_id.lower()
    if(customer_users.find_one({"email":str(email_id)})):
        return jsonify({"status":"email_id already exists"}),400
    else:
        return jsonify({"status":"email_id does not exist"}),200
        
#---------check user function ends---------
#---------------Create Admin-----------------------------
@app.route('/createadmin', methods = ['GET','POST'])
def admins():
    if(flask.request.method == 'GET'):
         data=retrieveAdmin(customer_users)
         return jsonify({"entries":data})
    else:
        if(request.get_json):
            content = request.get_json(silent=True)
            content["email"]=content["email"].lower()
            if(customer_users.find_one({"email":content["email"]})):
                data=retrieveAdmin(customer_users)
                return jsonify({"status":"Email id already exists. Please create customer with different email-ID","entries":data})
            else:
                password=randomString()
                content["customer_id"]=str(randomCustomer())
                content["password"]=password
                content["role"]="admin"
                customer_users.insert_one(content)
                data=retrieveAdmin(customer_users)
                return jsonify({"status":"New Admin created successfully","entries":data})
   
    
#-----------------ends-------------------------------------------
        
    
#---------------Create User-----------------------------
@app.route('/createuser', methods = ['GET','POST'])
def users():
    if(flask.request.method == 'GET'):
         data=retrieveData(customer_users)
         return jsonify({"entries":data})
    else:
        if(request.get_json):
            content = request.get_json(silent=True)
            content["email"]=content["email"].lower()
            if(customer_users.find_one({"email":content["email"]})):
                data=retrieveData(customer_users)
                return jsonify({"status":"Email id already exists. Please create customer with different email-ID","entries":data})
            else:
                password=randomString()
                content["customer_id"]=str(randomCustomer())
                content["password"]=password
                content["role"]="user"
                customer_users.insert_one(content)
                data=retrieveData(customer_users)
                return jsonify({"status":"New customer details created successfully","entries":data})
   
    
#-----------------ends-------------------------------------------
        
#-----------------Create assessment------------------------------
@app.route('/createassesment', methods = ['GET','POST'])
def assessments():
    if(request.get_json):
        content = request.get_json(silent=True)
        print(content)
        content["customer_id"]=str(content["customer_id"])
        content["question_uploaded"]=False
        content["status"]="Not Started"
        customer_id=str(content["customer_id"])
        assessment_id=randomAssessment()
        print(assessment_id)
        if (content["noGo"]==0 and content["maybe"]==0):
            content["noGO"]=50
            content["maybe"]=0
        if(assessment.find_one({"assessment_id":assessment_id})):
            return jsonify({"status":"assessment already present"})
        else:
            content["assessment_id"]=assessment_id
            customer_users.update_one(
                {"customer_id": customer_id},
                {"$set": {"assessments."+assessment_id:content}})
            assessment.insert_one(content)
            return jsonify({"statusCode":int(200),"status":"Assessment successfuly created"})
    else:
        return jsonify({"status":"error in the input json"})
#----------------------ends ---------------------------------------
        
#---------------------upload questions----------------------------
@app.route('/uploadQuestion/<assessment_id>', methods = ['GET','POST'])
def questions(assessment_id):
    print(assessment_id)
    if 'questionfile' not in request.files:
        return jsonify({'error': 'no file'}), 400
    for f in request.files.getlist('questionfile'):
        input_data=pd.read_csv(f,index_col=0)
    try:
        data = EH.validate_data(input_data)
    except ColumnsIdMismatch:
        return jsonify({"status":'Column IDs are not correct . Please check the documentation for the IDs reference'}),500
    except RowsIdMismatch:
        return jsonify({"status":'Questions ID are not in the proper format'}),500
    except InvalidClassId:
        return jsonify({"status":'Input type is not proper'}),500
    except InvalidCategoryId:
        return jsonify({"status":'Categories values are not matching'}),500
    except EmptyDataFrameException:
        return jsonify({"status":'Dataframe is empty'}),500
    data=input_data.to_json(orient='index')
    result=json.loads(data)
    customer=assessment.find_one({"assessment_id": assessment_id})
    customer_id=str(customer["customer_id"])
    assessment.update_one(
    {"assessment_id": assessment_id},
    {"$set": {"assessment_questions":result,"question_uploaded":True,"status":"In Progress"}})

    mydoc = assessment.find_one({"assessment_id":assessment_id})
    x=json.loads(json_util.dumps(mydoc))
    customer_users.update_one({"customer_id":customer_id},{"$set":{"assessments."+assessment_id+".question_uploaded":True}})
    customer_users.update_one({"customer_id":customer_id},{"$set":{"assessments."+assessment_id+".status":"In Progress"}})

    return jsonify({assessment_id:x,"status":"Assessments questions are uploaded successfully"})

#--------------------------------------------------------------------------- 
@app.route('/getassessments/<int:customer_id>', methods = ['GET','POST'])
def all_assessments(customer_id):
    x=customer_users.find_one({"customer_id":str(customer_id)})
    if(x["assessments"]):
        return jsonify({"assessments":x["assessments"]})
    else:
        return jsonify({"status":"You dont have any active assessments yet"}),500
        
    
#---------------------------------------------------------------------------

@app.route('/getquestions/<assessment_id>', methods = ['GET','POST'])
def all_questions(assessment_id):
    print(assessment_id)
    x=assessment.find_one({"assessment_id":assessment_id})
    data=x["assessment_questions"]
    return jsonify(data)

@app.route('/update_assessment/<assessment_id>', methods = ['GET','POST'])
def update_assessment(assessment_id):
    if(request.get_json):
        content = request.get_json(silent=True)
        assessment.update_one(
                {"assessment_id": assessment_id},
                {"$set": {"assessment_questions":content}})
        return jsonify({"status":"assessment updated"})
    else:
        return jsonify({"status":"assessment not updated structure error"})

@app.route('/performAssessment',methods=['GET','POST'])
def perform_assessment():
        app_assessment={}
        assessment_id=str(request.args['assessment_id'])
        customer_id=str(request.args['customer_id'])
        application_status=str(request.args['status'])
        content=request.get_json(silent=True)
        result_response=content['data']
        data=pd.DataFrame(result_response)
        x=assessment.find_one({"assessment_id":assessment_id})
        data_response=data.to_json(orient='index')
        app_response=json.loads(data_response)
        applications=list(app_response.keys())
        for i in range(1,len(applications)):
            application_assessment(assessment,app_response[applications[i]],assessment_id,recommendations)
        app_assessment["applications"]=app_response
        app_assessment["assessment_id"]=assessment_id
        app_assessment["customer_id"]=customer_id
        if(user_applications.find_one({"customer_id":customer_id,"assessment_id": assessment_id})):
            user_applications.update_one(
                {"assessment_id": assessment_id},
                {"$set": {"applications":app_response}})
        else:
            user_applications.insert_one(app_assessment)
        print("assessment complete")
        no_application=len(applications)-1
        print("before_update")
        if(application_status=="Completed"):
            customer_users.update_one({"customer_id":customer_id},{"$set":{"assessments."+assessment_id+".status":"Completed"}})
        elif(application_status=="Saved"):
            customer_users.update_one({"customer_id":customer_id},{"$set":{"assessments."+assessment_id+".status":"Saved"}})
        print("update_done")
        assessment.update_one(
        {"assessment_id": assessment_id},
        {"$set": {"no_of_app":str(no_application)}})
        customer_users.update_one({"customer_id":customer_id},{"$set":{"assessments."+assessment_id+".no_of_app":str(no_application)}})
        x=json.loads(json_util.dumps(app_assessment["applications"]))
        return jsonify({"data":x,"status":"Application assessment is complete"})
    
@app.route('/getSavedAssessment',methods=['GET','POST'])
def get_saved_assessment():
        assessment_id=str(request.args['assessment_id'])
        customer_id=str(request.args['customer_id'])
        x=user_applications.find_one({"customer_id":customer_id,"assessment_id": assessment_id})
        input_data=pd.DataFrame.from_dict(x["applications"])
        input_data=input_data.drop("scores")
        data=input_data.to_json(orient='index')
        result=json.loads(data)
        return jsonify({"data":result})           
            

#-----------------------------Delete assessment-----------------------------------------
        
@app.route('/deleteassessment',methods=['GET','POST'])
def delete_assessment():
        assessment_id=str(request.args['assessment_id'])
        customer_id=str(request.args['customer_id'])
        assessment.delete_one({"customer_id":customer_id,"assessment_id": assessment_id})
        x=customer_users.find_one({"customer_id":customer_id})
        assessments=x["assessments"]
        if(assessment_id in assessments):
            del assessments[assessment_id]
        customer_users.update_one({"customer_id":customer_id},{"$set":{"assessments":assessments}})
        return jsonify({"status":"Assessment deleted"}) 
    
#----------------------------------------------------------------------------------------------------
        
#-------------------------------Get applcation details -------------------------------------------
@app.route('/getAppAssessment',methods=['GET','POST'])
def get_app_assessment():
        assessment_id=str(request.args['assessment_id'])
        customer_id=str(request.args['customer_id'])
        x=user_applications.find_one({"customer_id":customer_id,"assessment_id": assessment_id})
        input_data=pd.DataFrame.from_dict(x["applications"])
        data=input_data.to_json(orient='index')
        result=json.loads(data)
        return jsonify({"data":result})

    
    
#----------------------------------------------------------------------------------------------------------
        
@app.route('/getAppReport',methods=['GET'])
def get_app_result():
        assessment_id=str(request.args['assessment_id'])
        customer_id=str(request.args['customer_id'])
        x=user_applications.find_one({"customer_id":customer_id,"assessment_id": assessment_id})
        app_details=pd.DataFrame.from_dict(x["applications"])
        app_details=app_details.drop("scores",axis=0)
        app_details=app_details.rename_axis('Id').reset_index()  
        row1=app_details.iloc[0].tolist()
        colnames=app_details.columns
        k=[]
        for i in range(2,len(colnames)):
            k.append(str(colnames[i])+":"+str(row1[i]))
        columns=["QID","Question"]
        columns.extend(k)
        app_details.columns=columns
        app_details=app_details.drop(index=0)
        csv_report=app_details.to_json(orient='records')
        return csv_report 

    
#----------------------------------------------------------------------------------------------------------

@app.route('/getReport',methods=['GET','POST'])
def get_app_report():
        assessment_id=str(request.args['assessment_id'])
        customer_id=str(request.args['customer_id'])
        x=user_applications.find_one({"customer_id":customer_id,"assessment_id": assessment_id})
        input_data=pd.DataFrame.from_dict(x["applications"])
        data=input_data.to_json(orient='index')
        result=json.loads(data)
        scores=result["scores"]
        names=result["name"]
        list_scores=[]          
        scores.pop("Qid")
        for i in scores:
            scores[i]["App_name"]=names[i]
            scores[i]["ID"]=i
            list_scores.append(scores[i])
        return jsonify({"scored_data":list_scores})       
########Change password###############
@app.route('/changePassword', methods = ['GET','POST'])
def check_password():
    if(request.get_json):
        content=request.get_json(silent=True)
        try:
            document=customer_users.find_one({"email":content["email"]})
            if(document["password"]==str(content["oldpassword"])):
                customer_users.update_one({"email":content["email"]},{"$set":{"password":content["password"]}})
                return jsonify({"status":"Password updated"})
            else:
                jsonify({"status":"Password does not match"})
        except:
            jsonify({"status":"No entry found"})
            
    else:
        return jsonify({"status":"Error occurred"})
    
@app.route('/csvtojson',methods=['GET','POST'])
def csvtojson():
    if 'responsefile' not in request.files:
        return jsonify({'error': 'no file'}), 400
    for f in request.files.getlist('responsefile'):
        if f.filename.endswith('.csv'):
            input_data=pd.read_csv(f,index_col=0)
        else:
            input_data=pd.read_excel(f,index_col=0)
        data=input_data.to_json(orient='index')
        result=json.loads(data)
        assessment_id=str(request.args['assessment_id'])
        customer_id=str(request.args['customer_id'])
        assessment_response=pd.DataFrame(result)
        x=assessment.find_one({"assessment_id":assessment_id})
        qid_response=assessment_response.columns.tolist()
        qid_master=list(x["assessment_questions"].keys())
        print(qid_master)
        print(qid_response)
        flag = 0
        if(all(x in qid_response for x in qid_master)): 
            flag = 1
        if(flag):
            data=input_data.to_json(orient='index')
            result=json.loads(data)
            return jsonify({"data":result})
        else:
            return jsonify({"status":"Questions ID does not match"}),500
            

########Change password ends############
#########Get template################
@app.route('/gettemplate',methods=['GET','POST'])
def template():
    assessment_id=str(request.args['assessment_id'])
    try:
        x=assessment.find_one({"assessment_id":assessment_id})
        data=x["assessment_questions"]
        data1=pd.DataFrame.from_dict(data,orient='index')
        input_data=pd.DataFrame.from_dict(data1).rename_axis('Id').reset_index()
        questions = pd.DataFrame()
        questions["Id"]=input_data["Id"]
        questions["Qid"]=input_data["Question"]
        new_row = pd.DataFrame({'Id':'name', 'Qid':'Questions'},index =[0]) 
        questions = pd.concat([new_row,questions ])
        template=questions.to_json(orient='records')
        return template
    except:
        return jsonify({"status":"assessment Id not proper"})
################################################      
@app.route('/userLogin', methods = ['GET','POST'])
def user_login():
    if(request.get_json):
        content=request.get_json(silent=True)
        try:
            document=customer_users.find_one({"email":content["email"].lower()})
            if(document["password"]==str(content["password"])):
                if(content["loginRole"]=="admin"):
                    if(document["role"]=="user"):
                        return jsonify({"status":"You dont have admin access"}),200
                    else:
                        return jsonify({"status":"User verified","role":document["role"],"customer_id":document["customer_id"],"customer_name":document["customer_name"]}),200
                else:
                    return jsonify({"status":"User verified","role":"user","customer_id":document["customer_id"],"customer_name":document["customer_name"]}),200
            else:
                return jsonify({"status":"Password did not match"})
        except:
            return jsonify({"status":"No user name found"})
    else:
        return jsonify({"status":"No request json"})
        

            

@app.route("/sendmail/<usermail>")
def index(usermail):
   try:
       document=customer_users.find_one({"email":usermail})
       password=document["password"]
       msg = MIMEMultipart()
       message = "Your one time password is "+ password +". Request you to please change it during first login"
       password = "Transformer1"
       msg['From'] = "mcma.admin@mphasis.com"
       msg['To'] = usermail
       msg['Subject'] = "mCMA one time password."
       msg.attach(MIMEText(message, 'plain'))
       server = smtplib.SMTP('indiamail.mphasis.com: 25')
       server.starttls()
       server.login(msg['From'], password)
       server.sendmail(msg['From'], msg['To'], msg.as_string())
       server.quit()
       return jsonify({"status":"Email with one time password is sent"})
   except Exception as e:
       print(e)
       return jsonify({"status":"Cannot send mail  ,Error occured"})

app.run(host="0.0.0.0", port=5000,threaded =True)

