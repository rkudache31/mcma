# -*- coding: utf-8 -*-
"""
Created on Wed Aug 14 06:34:57 2019

@author: Administrator
"""
import pandas as pd
import numpy as np

    
def application_assessment(assessment,applications,assessment_id,recommendations):
    '''It takes the application id and assessment ID
    performs quick assessment , and appends the input response JSON 
    with (Score , recommendation , recommendation type)'''
    count=0
    recommendation_type=[]
    app=applications
    x=assessment.find_one({"assessment_id":assessment_id})
    for i in x["assessment_questions"].keys():
        if(x["assessment_questions"][i]["Type"]=="scoring"):
            count+=int(x["assessment_questions"][i][app[i]])
        elif(x["assessment_questions"][i]["Type"]=="text"):
            recommendation_type.append(x["assessment_questions"][i][app[i]])
        elif(x["assessment_questions"][i]["Type"]=="conditional"):
            #inside conditional it check if response is Yes and not NO, it fectches the link value 
            if((app[i]=="YES") & (x["assessment_questions"][i][app[i]]!="0")):
                ques=x["assessment_questions"][i][app[i]]
                response=app[x["assessment_questions"][i][app[i]]]
                count+=int(x["assessment_questions"][ques][response]) 
    if count<=x["noGo"]:
        recommendation="No GO"
    elif (count>x["noGo"] and count<=x["maybe"]):
        recommendation="Maybe"
    else:
        recommendation="GO"

    recommendation_type=np.trim_zeros(recommendation_type)
    recommendation_type,description=get_Recommendation(recommendations,recommendation_type)
    app["scores"]={"score":count,"recommendation":recommendation,"recommendation_type":recommendation_type,"Description":description}

def get_Recommendation(recommendations,R_list):
    i=[]
    for val in R_list: 
        if val != None : 
            i.append(val)
    print(i)
    r_data=recommendations.find_one({"version":"v1"},{ "_id": 0, "version": 0} )
    data=pd.DataFrame.from_dict(r_data["recommendations"])
    if(len(i))==0:
        result=data["Result"][0]
        recommendation=data["Assessment Summary"][0]
    elif(len(i)==1):
        if 'Remediate' in i:
            result=data["Result"][4]
            recommendation=data["Assessment Summary"][4]
        elif'Replatform' in i:
            result=data["Result"][2]
            recommendation=data["Assessment Summary"][2]
        elif'Refactor' in i:
            result=data["Result"][1]
            recommendation=data["Assessment Summary"][1]
    elif(len(i)==2):
        if ['Remediate','Replatform'] in i:
            result=data["Result"][4]
            recommendation=data["Assessment Summary"][4]
        elif ['Remediate','Refactor'] in i:
            result=data["Result"][5]
            recommendation=data["Assessment Summary"][5]
        else:
            result=data["Result"][3]
            recommendation=data["Assessment Summary"][3]
    else:
        result=data["Result"][7]
        recommendation=data["Assessment Summary"][7]
    return(result,recommendation)
    