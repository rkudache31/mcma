class ColumnsIdMismatch(Exception):
    """
    Exception raised when the input assessment dataframe
    does not have proper column Id
    """
    pass

class RowsIdMismatch(Exception):
    """
    Exception raised when the input assessment dataframe
    does not have proper Rows Id
    """
    pass

class InvalidClassId(Exception):
    """
    Exception raised when the input assessment dataframe
    does not have valid Class names
    """
    pass

class InvalidCategoryId(Exception):
    """
    Exception raised when the input assessment dataframe
    does not have Valid Category names
    """
    pass


class EmptyDataFrameException(Exception):
    """
    Exception raised when the input assessment dataframe
    is empty
    """
    pass
