export const environment = {
  production: true,
  apiUrl: "http://18.191.158.237:5000/"
};
