import { Component, OnInit } from "@angular/core";
import { SharedService } from "../../services/shared.service";
import { Router } from "@angular/router";
import { AuthService } from "../auth/auth.service";
import {
  MatSnackBar,
  MatSnackBarConfig,
  MatSnackBarHorizontalPosition,
  MatSnackBarVerticalPosition
} from "@angular/material";

@Component({
  selector: "app-login",
  templateUrl: "./change-password.component.html",
  styleUrls: ["./change-password.component.css"]
})
export class ChangePasswordComponent implements OnInit {
  username: string;
  oldPassword: string;
  newPassword: string;
  confirmNewPassword: string;
  role: string;
  horizontalPosition: MatSnackBarHorizontalPosition = "center";
  verticalPosition: MatSnackBarVerticalPosition = "top";

  constructor(
    private authService: AuthService,
    private sharedService: SharedService,
    private snackBar: MatSnackBar,
    private router: Router
  ) {}

  ngOnInit() {
    this.authService.currentRole.subscribe(res => (this.role = res));
  }
  changePassword() {
    let username;
    this.authService.currentUserName.subscribe(res => (username = res));
    let data = {
      email: username,
      oldpassword: this.oldPassword,
      password: this.newPassword
    };
    this.sharedService.postChangePasswordDetails(data).subscribe((res: any) => {
      let config = new MatSnackBarConfig();
      // config.extraClasses = true ? ['custom-class'] : undefined;
      config.verticalPosition = this.verticalPosition;
      config.horizontalPosition = this.horizontalPosition;
      config.duration = 2000;
      this.snackBar.open(res.status, "", config);
      setTimeout(() => {
        this.authService.logout();
      }, 2500);
    });
  }

  retainPassword() {
    if (this.role == "admin") {
      this.router.navigate(["/admin"]);
    } else {
      this.router.navigate(["/customer"]);
    }
  }
}
