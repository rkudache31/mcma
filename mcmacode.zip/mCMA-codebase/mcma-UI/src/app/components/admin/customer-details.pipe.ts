import { Pipe, PipeTransform } from "@angular/core";
import { element } from "@angular/core/src/render3";

@Pipe({
  name: "customerDetails"
})
export class CustomerDetailsPipe implements PipeTransform {
  transform(usersDetails: any, searchCustomerById?: any): any {
    console.log(usersDetails);

    if (!searchCustomerById) return usersDetails;
    return usersDetails.filter(element => {
      return (
        element.customer_id.toString().includes(searchCustomerById) ||
        element.customer_name
          .toLowerCase()
          .includes(searchCustomerById.toLowerCase())
      );
    });
  }
}
