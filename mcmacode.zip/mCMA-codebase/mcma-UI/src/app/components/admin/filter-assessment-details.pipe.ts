import { Pipe, PipeTransform } from "@angular/core";

@Pipe({
  name: "filterAssessmentDetails"
})
export class FilterAssessmentDetailsPipe implements PipeTransform {
  transform(assessmentDetails: any, searchAssessmentById?: any): any {
    if (!searchAssessmentById) return assessmentDetails;
    return assessmentDetails.filter(element => {
      return element.assessment_id == searchAssessmentById;
    });
  }
}
