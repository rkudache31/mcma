import { CustomerDetailsPipe } from './customer-details.pipe';

describe('CustomerDetailsPipe', () => {
  it('create an instance', () => {
    const pipe = new CustomerDetailsPipe();
    expect(pipe).toBeTruthy();
  });
});
