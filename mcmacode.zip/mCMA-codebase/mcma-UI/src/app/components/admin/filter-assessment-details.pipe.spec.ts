import { FilterAssessmentDetailsPipe } from './filter-assessment-details.pipe';

describe('FilterAssessmentDetailsPipe', () => {
  it('create an instance', () => {
    const pipe = new FilterAssessmentDetailsPipe();
    expect(pipe).toBeTruthy();
  });
});
