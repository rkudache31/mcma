import { Component, OnInit } from "@angular/core";
import { SharedService } from "../../services/shared.service";
import * as jspdf from "jspdf";
import html2canvas from "html2canvas";
import { ChartOptions, ChartType, ChartDataSets } from "chart.js";
import * as pluginDataLabels from "chart.js";
import { Label } from "ng2-charts";
import { saveAs } from "file-saver";
import { ExcelService } from "../../services/excel.service";
import {
  FormGroup,
  AbstractControl,
  ValidatorFn,
  FormBuilder,
  Validators
} from "@angular/forms";
declare var htmlDocx: any;

function isAppIdExistFunc(tableHeaderKeys): ValidatorFn {
  return (control: AbstractControl): { [key: string]: boolean } | null => {
    if (
      control.value !== undefined &&
      tableHeaderKeys !== undefined &&
      tableHeaderKeys.some(element => control.value == element)
    ) {
      return {
        isAppIdExist: true
      };
    }
    return null;
  };
}

@Component({
  selector: "app-customer",
  templateUrl: "./customer.component.html",
  styleUrls: ["./customer.component.css"]
})
export class CustomerComponent implements OnInit {

  assessmentMessage: string;
  customerId: string;
  assessmentDetails: any;
  applicationDetails: any;
  customerResposeInJson: any;
  tableHeaderKeys: any;
  currentAssessmentId: string;
  showQuestionDetails: boolean;
  showAppScoreDetails: boolean;
  appTableHeaderKeys: any;
  appScoreDetails: any;
  reportDetails: any;
  applicationName: string;
  applicationId: string;
  addColumnDetails: boolean = false;
  templateData: any;
  today: any;
  loginUser: string;
  currentAssessmentClientName: string;
  currentAssessmentType: string;
  currentAssessmentCreationDate: string;
  currentAssessmentEndDate: string;
  appFormGroup: FormGroup;
  isAppIdExist: boolean = false;
  message: string;

  public barChartOptions: ChartOptions = {
    responsive: true,
    // We use these empty structures as placeholders for dynamic theming.
    scales: { xAxes: [{}], yAxes: [{}] },
    plugins: {
      datalabels: {
        anchor: "end",
        align: "end"
      }
    }
  };
  public barChartLabels: Label[];
  public barChartType: ChartType = "bar";
  public barChartLegend = true;
  public barChartPlugins = [pluginDataLabels];
  score: any[] = [];
  public barChartData: ChartDataSets[];

  // Pie
  public pieChartOptions: ChartOptions = {
    responsive: true,
    legend: {
      position: "top"
    },
    plugins: {
      datalabels: {
        formatter: (value, ctx) => {
          const label = ctx.chart.data.labels[ctx.dataIndex];
          return label;
        }
      }
    }
  };
  public pieChartLabels: Label[];
  public pieChartData: number[];
  public pieChartType: ChartType = "pie";
  public pieChartLegend = true;
  public pieChartPlugins = [pluginDataLabels];
  public pieChartColors;

  constructor(
    private sharedService: SharedService,
    private excelService: ExcelService,
    private fb: FormBuilder
  ) {}
  ngOnInit() {
    this.appFormGroup = this.fb.group({
      appNameCtrl: [null, [Validators.required]],
      appIdCtrl: [null, [Validators.required]]
    });

    this.sharedService.currentLoginUser.subscribe(res => {
      this.loginUser = res;
    });
    this.sharedService.currentCustomerId.subscribe(res => {
      this.customerId = res;
      this.sharedService
        .getAssessmentDetails(this.customerId)
        .subscribe(
          res => {
            this.assessmentDetails = res;
            this.assessmentMessage = null;
          },
          err => {
            this.assessmentDetails = null;
            this.assessmentMessage = err.error.status;
          }
        );
    });
    this.today = new Date();
    var dd = this.today.getDate();

    var mm = this.today.getMonth() + 1;
    var yyyy = this.today.getFullYear();
    if (dd < 10) {
      dd = "0" + dd;
    }

    if (mm < 10) {
      mm = "0" + mm;
    }
    this.today = dd + "-" + mm + "-" + yyyy;
  }
  getApplicationScore(assessmentObj) {
    this.showQuestionDetails = false;
    this.currentAssessmentClientName = assessmentObj.clientName;
    this.currentAssessmentId = assessmentObj.assessment_id;
    this.currentAssessmentType = assessmentObj.assessment_type;
    this.currentAssessmentCreationDate = assessmentObj.start_date;
    this.currentAssessmentEndDate = assessmentObj.end_date;
    this.sharedService
      .getApplicationScoreData(this.customerId, this.currentAssessmentId)
      .subscribe((res: any) => {
        this.applicationDetails = res;
        console.log(res);
        this.showAppScoreDetails = true;
        console.log("this.appScoreDetails", (this.appScoreDetails = res));
        this.appTableHeaderKeys = Object.keys(this.appScoreDetails.data.name);
      });
    this.sharedService
      .getReportDetails(this.customerId, this.currentAssessmentId)
      .subscribe(res => {
        this.reportDetails = res;
        console.log("report ", this.reportDetails);
        this.score = [];
        this.barChartLabels = [];
        this.pieChartData = [];
        var noOfGo = 0;
        var noOfNoGo = 0;
        var noOfMaybe = 0;
        this.reportDetails.scored_data.forEach(element => {
          this.score.push(element.score);
          this.barChartLabels.push(element.App_name);
          element.recommendation == "GO"
            ? noOfGo++
            : element.recommendation == "Maybe"
            ? noOfMaybe++
            : noOfNoGo++;
        });
        if (noOfMaybe == 0) {
          this.pieChartData = [noOfNoGo, noOfGo];
          this.pieChartLabels = ["NOGO", "GO"];
          this.pieChartColors = [
            {
              backgroundColor: ["rgba(255,0,0,0.3)", "rgba(0,255,0,0.3)"]
            }
          ];
        } else {
          this.pieChartData = [noOfNoGo, noOfMaybe, noOfGo];
          this.pieChartLabels = ["NOGO", "MAYBE", "GO"];
          this.pieChartColors = [
            {
              backgroundColor: [
                "rgba(255,0,0,0.3)",
                "rgba(0,255,0,0.3)",
                "rgba(0,0,255,0.3)"
              ]
            }
          ];
        }
        this.barChartData = [{ data: this.score, label: "Score" }];
      });
  }

  downloadQuestion(assessmentId) {
    this.sharedService
      .getTemplateData(assessmentId)
      .subscribe((res: any) => {
        this.templateData = res;
        console.log(this.templateData);
        this.excelService.exportAsExcelFile(this.templateData, "sample");
      });
  }
  customerResponseAsCSV(event, assessmentObj) {
    this.currentAssessmentId = assessmentObj.assessment_id;
    this.currentAssessmentClientName = assessmentObj.clientName;
    this.currentAssessmentId = assessmentObj.assessment_id;
    this.currentAssessmentType = assessmentObj.assessment_type;
    this.currentAssessmentCreationDate = assessmentObj.start_date;
    this.currentAssessmentEndDate = assessmentObj.end_date;
    let file: File = event.target.files[0];
    let data = new FormData();
    this.showAppScoreDetails = false;
    data.append("responsefile", file);
    this.sharedService
      .postCustomerResponseAsCSV(
        data,
        this.currentAssessmentId,
        this.customerId
      )
      .subscribe(
        res => {
          console.log((this.customerResposeInJson = res));
          this.showQuestionDetails = true;
          this.tableHeaderKeys = Object.keys(
            this.customerResposeInJson.data.name
          );
        },
        err => {
          this.customerResposeInJson = null;
          this.showQuestionDetails = false;
          this.message = err.error.status;
        }
      );
  }
  showResponseDetails(assessmentId) {
    this.currentAssessmentId = assessmentId;
    this.sharedService
      .getQuestionRevisedResponse(this.customerId, assessmentId)
      .subscribe(res => {
        this.customerResposeInJson = res;
        this.showQuestionDetails = true;
        this.tableHeaderKeys = Object.keys(
          this.customerResposeInJson.data.name
        );
      });
  }
  appIdFunc() {
    this.appFormGroup
      .get("appIdCtrl")
      .setValidators(isAppIdExistFunc(this.tableHeaderKeys));
    this.appFormGroup.get("appIdCtrl").updateValueAndValidity();
  }
  addColumn() {
    for (let obj in this.customerResposeInJson.data) {
      if (obj == "name") {
        this.customerResposeInJson.data[obj][
          this.applicationId
        ] = this.applicationName;
        this.tableHeaderKeys = Object.keys(
          this.customerResposeInJson.data.name
        );
      } else {
        this.customerResposeInJson.data[obj][this.applicationId] = "NO";
      }
    }
    // this.customerResposeInJson.data.forEach(element => {
    //   console.log(element)
    // });
    // this.tableHeaderKeys.forEach((element, ind) => {
    //   if (ind == 0) {
    //     console.log(this.customerResposeInJson.data);
    //     this.customerResposeInJson.data.element[key] = this.applicationName;
    //   } else {
    //     console.log(this.customerResposeInJson.data);
    //     this.customerResposeInJson.data.element[key] = "NO";
    //   }
    // });
    this.addColumnDetails = false;
    this.applicationName = "";
  }
  saveCustomerRevisedResponse(status) {
    this.sharedService
      .postCustomerRevisedResponse(
        this.customerResposeInJson,
        this.currentAssessmentId,
        this.customerId,
        status
      )
      .subscribe(res => {
        console.log(res);
        this.showQuestionDetails = false;
        if (status == "Completed") {
          this.sharedService
            .getApplicationScoreData(this.customerId, this.currentAssessmentId)
            .subscribe((res1: any) => {
              this.applicationDetails = res1;
              console.log(res1);
              this.showAppScoreDetails = true;
              console.log(
                "this.appScoreDetails",
                (this.appScoreDetails = res1)
              );
              this.appTableHeaderKeys = Object.keys(
                this.appScoreDetails.data.name
              );
            });

          this.sharedService
            .getReportDetails(this.customerId, this.currentAssessmentId)
            .subscribe(res => {
              this.reportDetails = res;
              this.score = [];
              var noOfGo = 0;
              var noOfNoGo = 0;
              var noOfMaybe = 0;
              this.barChartLabels = [];
              this.reportDetails.scored_data.forEach(element => {
                this.score.push(element.score);
                this.barChartLabels.push(element.App_name);
                element.recommendation == "GO"
                  ? noOfGo++
                  : element.recommendation == "Maybe"
                  ? noOfMaybe++
                  : noOfNoGo++;
              });
              if (noOfMaybe == 0) {
                this.pieChartData = [noOfNoGo, noOfGo];
                this.pieChartLabels = ["NOGO", "GO"];
                this.pieChartColors = [
                  {
                    backgroundColor: ["rgba(255,0,0,0.3)", "rgba(0,255,0,0.3)"]
                  }
                ];
              } else {
                this.pieChartData = [noOfNoGo, noOfMaybe, noOfGo];
                this.pieChartLabels = ["NOGO", "MAYBE", "GO"];
                this.pieChartColors = [
                  {
                    backgroundColor: [
                      "rgba(255,0,0,0.3)",
                      "rgba(0,255,0,0.3)",
                      "rgba(0,0,255,0.3)"
                    ]
                  }
                ];
              }
              this.barChartData = [{ data: this.score, label: "Score" }];
            });
        }
        this.sharedService
          .getAssessmentDetails(this.customerId)
          .subscribe(res => {
            this.assessmentDetails = res;
          });
      });
  }
  public captureScreen() {
    var data = document.getElementById("contentToConvert");

    var pdf = new jspdf();
    pdf.fromHTML(data, 20, 20, { width: 500 });
    pdf.save("test.pdf");
    // html2canvas(data).then(canvas => {

    //   var imgWidth = 100;

    //   var pageHeight = 295;

    //   var imgHeight = (canvas.height * imgWidth) / canvas.width;

    //   var heightLeft = imgHeight;

    //   const contentDataURL = canvas.toDataURL("image/png");

    //   let pdf = new jspdf("p", "mm", [1500, 2000]);

    //   var position = -20;

    //   pdf.addImage(contentDataURL, "PNG", 0, 0);

    //   pdf.save("MYPdf.pdf");
    // });
  }
  // events
  public chartClicked({
    event,
    active
  }: {
    event: MouseEvent;
    active: {}[];
  }): void {
    console.log(event, active);
  }

  public chartHovered({
    event,
    active
  }: {
    event: MouseEvent;
    active: {}[];
  }): void {
    console.log(event, active);
  }

  downLoadReport() {
    this.sharedService
      .getReportData(this.currentAssessmentId, this.customerId)
      .subscribe((res: any) => {
        this.templateData = res;
        console.log(this.templateData);
        this.excelService.exportAsExcelFile(
          this.templateData,
          "Report of " + this.currentAssessmentId
        );
      });
    // var canvas = document.getElementById("myChart");
    var barCanvas: any = document.getElementById("barChart");
    var barDataURL = barCanvas.toDataURL();
    var pieCanvas: any = document.getElementById("pieChart");
    var pieDataURL = pieCanvas.toDataURL();
    //var dataURL = canvas;
    var styles = `
       #body_word h1 {
      font-size: 18px;
      font-weight: bold;
      color: blue;
  }
  #body_word h2 {
    font-size: 40px;
    font-weight: bold;
    color: blue;
}
 
#table .table {
  width: 100%;
}
#table th {
  background: #3d95ad;
  padding: 5px;
  color: white;
}
#table td {
  padding: 5px;
  max-width: 400px;
  height: min-content;
}
  /*new css*/
  #body_word table{
  border-collapse: collapse;
  }
 
  #body_word td,  th {
    border: 1px solid #000;
    padding: 0 10px;
}
#body_word thead tr{
  background-color: #639cfd;
}
#body_word thead th{
  color: #fff;
}
#body_word th {
  text-align: center;
  color: #000;
  font-weight: bold;
  font-size: 14px;
}
#body_word table {
width: 100%;
}
#body_word .report_body3 {
text-align:center;
color:blue;
}
#body_word .report_body2{
border:1px solid #ccc;
}

#body_word .header-body5 {
border-left: 3px solid blue; /*#639cfd */
padding-left: 20px;
margin-left:250px;
margin-top:100px;
margin-bottom:170px;
}
#body_word .month-year-body5{
margin-left:250px;
color:blue;
}
#body_word .margin20{
margin:10px 0;
}
#body_word .fnt-wt{
font-weight:bold;
font-size:24px;
}
#body_word .summary-body5 li {
margin: 10px 0;
}
#body_word .executive-summary-body5{
 margin-top:200px;
}
#body_word .tablefigures-body5 div {
margin: 10px 0;
}
#body_word .tablefigures-body5 {
border-top: 1px solid #ccc;
border-bottom: 1px solid #ccc;
padding: 30px 0;
margin-top: 30px;
}
#body_word .introduction-body5 .even{
background-color: #cee5ef;
}
#body_word .introduction-body5{
margin-top: 580px;
}
#body_word .introduction-table-body5{
  margin-top:30px;
  margin-bottom:30px;
}
#body_word .nonEditable{
background: #ccd0d2;
}
#body_word .tableNonEditable{
background:gray;
color:white;
border-right:1px solid white !important;
}
#body_word .tdWidth{
max-width:45px;
}
#body_word .report_body5 th {
width: 50%;
}
     v\:* {behavior:url(#default#VML);}
     o\:* {behavior:url(#default#VML);}
     w\:* {behavior:url(#default#VML);}
     .shape {behavior:url(#default#VML);}
     @page
     {
         mso-page-orientation: landscape;
         size:29.7cm 21cm;    margin:1cm 1cm 1cm 1cm;
     }
     @page Section1 {
         mso-header-margin:.5in;
         mso-footer-margin:.5in;
         mso-header: h1;
         mso-footer: f1;
         }
     div.Section1 { page:Section1; }
     table#hrdftrtbl
     {
         margin:0in 0in 0in 900in;
         width:1px;
         height:1px;
         overflow:hidden;
     }
     p.MsoFooter, li.MsoFooter, div.MsoFooter
     {
         margin:0in;
         margin-bottom:.0001pt;
         mso-pagination:widow-orphan;
         tab-stops:center 3.0in right 9.0in;
         font-size:12.0pt;
     }
     .innerhead{
       font-size:11px !important;
       padding-left:2px !important;
       padding-right:2px !important;
     }
     #timeline th{
        background: #1394d0;
        color:white;
        font-size:16px;
        vertical-align: middle;
     }
     .divBorderBottom{
      margin: 5px 0px 5px 0px;
      border-bottom-style: solid;  
      border-bottom-width: thin;
      border-bottom-color: rgb(73, 149, 184)
     }
     
`;

    var content =
      `<html xmlns:v="urn:schemas-microsoft-com:vml"
     xmlns:o="urn:schemas-microsoft-com:office:office"
     xmlns:w="urn:schemas-microsoft-com:office:word">
     <head><meta http-equiv=Content-Type content="text/html; charset=utf-8"><title></title>
     <style>` +
      styles +
      `
   
    </style>
     <xml>
     <w:WordDocument>
     <w:View>Print</w:View>
     <w:Zoom>100</w:Zoom>
     <w:DoNotOptimizeForBrowser/>
     </w:WordDocument>
     </xml>
     </head>
     
     <body>
     <div class="Section1">
          <!-- body starts here -->
          <div id="body_word"><br>
          <h3>Cloud Migration Readiness Assessment Report Done for ` +
      this.currentAssessmentClientName +
      `</h3>
          <h4>Report generated on ` +
      this.today +
      `</h4>
          <h5>Generated By: ` +
      this.loginUser +
      `</h5>

      <h4>Assessment Summary:</h4>
     <table>
      <tr>
        <td>Assessment Id: ` +
      this.currentAssessmentId +
      `</td>
        <td>Assessment Type: ` +
      this.currentAssessmentType +
      `</td>
      </tr>
      <tr>
        <td>Assessment Creation date: ` +
      this.currentAssessmentCreationDate +
      `</td>
        <td>Assessment End Date: ` +
      this.currentAssessmentEndDate +
      `</td>
      </tr>
     </table>
     <br><br>
          ` +
      document.getElementById("download_reports").innerHTML +
      `<br>
    <img src="` +
      barDataURL +
      `" width="900"/>
      <img src="` +
      pieDataURL +
      `" width="900"/>
          </div>
          <!-- body Ends here -->
         <table id='hrdftrtbl' border='0' cellspacing='0' cellpadding='0'>
         <tr>
            <td>
                  <div style='mso-element:header' id=h1 >
                    <!-- HEADER-tags -->
                   
                    <table style="border-bottom: 2px solid #ccc;" width="100%" cellpadding="0" cellspacing="0">
                          <tr>
                          <td style="text-align: left;">
                          mCMA – Go/No Go Assessment Report
                          </td>
                          <td style="text-align: right;">
                          <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAAA4CAYAAAC4yreHAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsQAAA7EAZUrDhsAABmnSURBVHhe7Z0JYFNV9v+/XZKmC3Sh2LIogqC4oagoAuKMwgw6DIo6+nP9KSCi8ndD/y7jACPuisvgghuyiAqoICMDIquKKCqL4AYWCpS9tLRNlyRN3u9+b+5rX15e0rRNK2Xykdh371uSvNxz7znn3nNenCZAIyj9Lh8HF/yAzuOGqJoYMY4c4tXfBuGt8mDjhf/C9vELkD/h36o2Rowjh0YJyObbZ8LnqoajXRbyx36CHRMXqz0xYhwZNFhAfO5qHJyzAYkZKbLsyM3C1nvnYMdzn8lyjBhHAg0WkIqf98JbVom4+Dh/hfjjyM1G3pgPsGfWd/66JsTr9aKiogIulwtVVVXy1RiM13I6naq2adE/d2VlJdxut6o9sigrK1NbLZMGC4jnoFPIhOl0CklOJn64/m1se3mFqmwaZsyYgdTUVDgcDiQnJ8vXt99+q/bWj4EDBwZcq23btmpP09K1a1f5fikpKbjvvvtU7ZGBx+NB79690bp1a2RkZGDt2rVqT8uiUTYIEOwA43iS0ikTv4z7Nwrmr/dXNgEJCQlqq5Y+ffqorch5/vnnsWTJElXyExenRsUmxvg+iYmJauvI4KOPPsI333wjt0tKSnDnnXfK7ZZGgwUkqWOmhXj40YSYJGWn4dthM5A3Y7WqbXqqq6vxhz/8QZXqZv/+/bjnnntUqZb4+Eb2GxFifJ/mEsrmwvx9+Nu0RBrcEpKPz5EGuub1qZpAeH9SO2Zg3bj52LnkJ1Xb9KxcuRLLli1TpfCceeaZaitGtLn88stxyimnqBLwyiuvqK2WRYMFhP1D7i39hC1S7q+wIE785ziqFVaMmIH8xc0nJBdeeCF27NihStZceeWVKCgoUKUY0YYq8MaNG+Hz+cC56J49e6o9LYtG6RLHPTkUtuxUeCvCeGCEJKV1yMSqh+ZiaxMKydFHH622/FxxxRVqK5iff/4Zc+bMUSU/rVq1UlsxoklLVx0brWyfnf+oFAJOGIZE3CR7Kwc+/X+zsf3LPFUZXT788EN07txZlSA9WnfccYcq1VJcXIyTTjpJlfzMnTsXSUlJqmTNr7/+ivvvvx/jxo3Dgw8+qGr91/v73/+OE044AW3atEFubq5UL9577z11RP2g+5oeuosuugjHHXec9ASNGTMGX331lToiMj755BNcffXV8vNkZ2fLz3bJJZdg8eLaydzHHntMfp8HHngAn3/+uaoNZvbs2RgwYID07qWlpSE9PV1e7y9/+Yu8d1bQ5uC19et/8cUXak8wM2fORL9+/eQ16U2k56tDhw7y84f7XM0C12I1lsrtB7WVjtu0VW3u01bn3K+t7Pqwtqz7WG3xaRO0f/d+TPuo79PanD9O1N694Hnt9X4Tte3f5KszG8706dPpI6h5rVixQsvLywuo42v16tXqDD/9+/cP2D906FBZL1SCmjrxI8k6I/Pnzw84jzzzzDMBdeaX+MG1//znP/JYK4455piaYx999FFNqIVaSkpKwDWMr8GDB6szQ7NhwwZNCJbl+frr4osvlsc6HI6aOr6/GaGCau3btw841+rVvXt37fvvv1dn+amoqAg45oknnlB7avnll1+0jIyMgOOsXr169dL27NmjzmpeGj2CEMcxWei1eQLcRaXQPNZGO+Foa09LwuxhM7Hvl32qNjpwsq1Lly54+eWXVY0f2iM67JnNPRLdkUTcC/k3FMYRxmazyVGjrrmLgwcPQjRGiMahakLDnlgIjJywDAVHhdNOO02VgmFPzP2io1A11gihxbnnnousrCxVAzkXY2Tz5s3o2LEjdu/erWpCIxp6wH0m9NAZXdec7zHCEV4IFg4dOqRqQsNjOaL+HkRFQEjy0Vk4Z8sjqHa7AI9X1QYim6CQkqxOWXj/ttk4sK1Q1keT2267LUCFYoMbNmyY9MXfcMMNqtZPQ4dvToI9/vjjqgQcf/zxUp2jOjF8+PCgOZqHHnoIy5cvVyVrRA+stoDzzz8f//znP+XrnHPOUbV+fvjhB0yePFmVahE9LK677jpV8kOV6JFHHsGqVavkXI8YJXDUUUfJfV9//XVA4zd3EGbhp5q3fft2HDhwQL62bt0qvxehcNFlXh/uvfdeteXnrbfekt+B1+H1169fX+OCp325bt06ud3syHEkilQVFGuLk0drS7s9HKxiXfi8Nm3QS9qbF7+i/Uv8vbf7P7S9BUXqzPphVrEWLlyo9vgx7rN6vf766+pIP6LHq9lnpWJ9+umnAefrr7Vr16ojAhH6fcBxOTk5ak8tRhVLf4lGqPbWQvXReAxVKDN9+vQJOGbkyJFqTzBDhgwJOJaviRMnqr1+qB7q+4QtoGqDcTqdlupPVVWVJkaQmmu88MILao8fvZ6vCRMmqNpgdu7cqYlRRpWan6iNIDpJHTJw5sI74C5xSRdfLZr0aGiaD9W+arg0FxztUjDhoglwrvpVHRM9qEaE4uSTT8bNN9+sSg1n0aJFId2X7F2Ns8f79u2rmVkOBVUkqllmOKIYRz+zCsVrG414qiOvvfaaKgXz8ccf4/TTT1cla2gs66xZs0ZtBcPj6AioL0b1i3NXoaCaR6fA70WjBOSTvBI88c0+vLS+EFuKhWqlyDq/G87++BZU7S9DHCcS6ekTfYVP/M9N4ah2o9xThb1aBW7efgC7+gXPZjcWNpKbbrpJlQKpS92JBNo7f/7zn1XJGtFrqi0/L774otoKhl6wa665RpWCGTVqlNrys2XLFrVVa0fphHsfHTFiqC1rjDYFBZKeMKp2VM2oAlHNbAyDBg1SW5DqH5cJTZs2TapWRUVFh83Me4MEZFeZCwPe34IHv9iD938pxqR1B3DBh79hzMpd6gghJL2Pwx+X3YOqwnIhGT7QKvFUe1ElBKPcUwFnZQlGbdqB1vEJYl8K9tz+uv/EKDJlyhRpHxihuzEaixE50RgJffv2VVt+V3Eo6DINh3meR6geagvYtGmT2vLP53Tr1k2VQnP22WeHXf9FZ4fRbU6Hw6233iqNe9oxdrtdfqZrr71WGun15dVXXw14/9WrV+PGG2+UIzLdvXSE8Ldjx0B75/ei3gJSXOnBVR/ny+3c5HhkORJxlHh1TLVh+o/FmLW5SO4jrU9qh75Th8G5q1gIhwdVPgqHCzu85bjx5z3I8ogRJT4OCekpKJm2HNUHStWZ0WPBggVqC1Ktor89GvBHjASuZNUJt/S7rvVfgepq4GJNoSqrLciGGwmczwh3LL1ObJiXXXaZqgmGKxHeffddnHjiidIZUB+oOnEUMjshjHCUpKrI+SC+z+9BvQRkR6kbl320DZmOBCQnxiOBrjyhNiWKRm4Tl+qUbsOMTYFuu9z+3TBw1i0o3n8QTlclilyluG7zfqQK88edEC+1rzjx11teDueyDf6TogiXlLM3PO+88yAMc1XbeCLt1YzeHaNb1YyxkdcXo4s2nJvYCD1YkRzLCVgK5wcffIBnn31WqoF0JWdmZqoj/NCDF85WCQVVNqpTFIAnn3wSQ4cOlWu4GHpghCOVcdRsLiIWkHKPF3cs3oHM5ETYRINmnFSiMLrlSwhJAsts7nHBP3TuOZ0x8KUbkFdUiCu2FaGDywuXOIHCoRMf70Dlyugb64Su32jPyJqXqljBhmWMUTGre9HCuCiQ80HffVd3wFpdDgMjdK5wdQBdvXQk6HYCQwWMTJo0SW3VD46GnDXnSgXaU1zDxfkRs6s5mh1cpEQkINsOuXDVvK1w2OKRJM6wiRuWECdGDwqFaOgs28Q2L5ZuC47TIN0Hnoq7s9PRplIY6WrkCEBInLc09MLHw43CwkKMHTtWlazp0aOH2vLDycWm4G9/+5va8sMlJXVhnjOxIpwnjNx1110BwlnXBKURCjLnPkLBidmnn35aLjvR4TxMc1OngOwv9+CBlQXC1rDBTntBvIQ8SOGg2pwgmjrrhMaFwgoPrj85cOjVyR80Ft7VefCK6wQJB/FpiLPbVKFlMGHCBDz88MNBHhe6XWnr/Pjjj6oG6NSpk/RUNQV0tRq9QlSfaOxahQ6zrq4Ze0KbggYybRBOsobC6E0zq13h4GgxYsQI3H333SE9VqwvLa21S81qV3MQVkC2l7hxy6c70dqeKIRDCIOQiHhlc4h/Qkhoh1C9ihPGuxf39crBoM7BPuu8s+5G5ac/IT4r9IpZnzDgUwecrEotBy74o8eFcytcWEj3L+cFOHttJNSivmhhVvmoBtGjxc/EORkusKTQsK4uXZ6NnjYF4eemo4F2B205zqFwyQtd2LR9GMevE+nc0tSpU2vUMV6H949uebp5OX9Fx8ro0aNlvZFQbvumJKSAcDR4cvUetEu1SZuDowTtjARu8684k0JCVatQqE1XnpiOm0/PVmfXsuvGf8H1/Q4khBEOjaNHYjJS+56oapqf+hjJ1JnZ+xn56aefpF6/bds2VVMLDdCmjoegV8pqwo2fiWvBaABTaHSoHhknJY3L0ukmpmfKCJe4sNFeeuml+Otf/yp7fqpJOlzew31GQt1TGuLt27dXJT+cdKWbl+7uwYMHB62p4zl0MTc3lgKSV1yFMct2IUnYE3LkEPcungLCl9jPsrQ/xE0tc1dj2KlZuLtX8GzqtgFjcWjaMiRm1eqRVvgOVSDz1oGwdfKvE4oEs4rQ2Kwmxh+zvDy8LcQl6W+88YbsCcO5Ss866yypl9MAtYKGrk5d72memLP6vv3795fL7y+44AJVYw2NXRrYnPDTMbugKfBstPrarXBwhDKqk4T3iC8d4/fjzPiuXbswffp0Kdh1wVHaPBnaXASlHt3ldOOZb/YJwRDKVJyGai+Xh4i/opf3iiN9YtsrtsU/YZ+4cU6HNPyjbzt1di27b3oJxVOXwJYVXi9lyK67ZD9O1Raqmsjgwjb2amyg7MnoT490bsKKzz77rGZugd/XvDqVcRTGmXOqFnxv/vBsSAzzpUuXagGNcxrK5l7YDCctme6HDenYY48N6+WiQHz55ZdyvoTn8PuG0/nZYBmTQnWJwsXPxclBqim6u5mjC20Svj/fm5/BCq48oJs3Pz9fdkz0znGylZOgV111VdBoQHgPly5dKj8vbQnaX7TDzPB78fr8rHR88Lfk5+E1OWJwiU19bJtoEyAgu50ejFu1GzkpdnkTmHyhWvzlahEfBUQcQ0EhhcJ4H9C5FW7pGdzDbL9gPMqXrxcjR93C4SkpRpcvnkJKv99PvYoEs4Dwh60ryCpGy6dGxarw+PDmxkJ0SLP7DW8a5FSthBol7Q1RoHOWalWp24seOamWwrF7xKtCOH6oWzg8XiEcB9Bl9bOHvXDE+O+lRkBmbz4ELmZIFMYFvVLx8T6/3UEBkd4qv2HOCcM/Ht1KqFXBNkfB9S+i+K2FQjjCr76kcHgrXOi68TWk9G6aybMYMaKBEhANW0vdSBFGuRQIYYXLEUQKBbdpmMehQqhEp+UkY4SFt2rvmKkofWeZsDnC2wFy5CgrQpe1T8NxSuACvBgxDjekgOwoc0sh8KtU/ko5+ccDhLpFQams9uGUbAfuPCuHpwRQPHMFDjz3nhg5Qq81Ilq1F9VlZUKteg6OHsEGW4wYhxtSQPaUV8NB1UqUOHLQmUN7g38pKAwz797GgdFnWLv8Dj7xEeyp4d2BmqcantJidN3yaotUq8xuVvPq2hhHJlJAvBqN8jiZqZ2Oznhhc8RLIYmHzZaEdJsPt/YMEUNBt+++cupgqiIYzV0tM8Eft+Z5JHWtf/TZ4QCXZ3PBHt2OXPtkjjuPcWQi3bzrCyuxdKcTdtHIvXTvis6Rcx6J9iTsLsjH5yun4c5LBuPqc60noH47cTS8BSWIswcH4GguD7yVbnTNewn2Y+uedIoR43BCjiAMdvJwFKH9IVSsOLHhEMJRdqgIS5fORNvcdnjnu1VY8qt1CvuMEQPhdgZnKNFcYuQod6Fb/isx4YjRIpECkp2ciFQ7VSyhKYlyit0GZ3kJ5i6ajeyOnZDSqjXatc3B1LWLsGbnRp4SQPaYS9Bm5BC4ivbDV1IBn7MK1UUl8LmFcBS8BtvRwV6vGDFaAjUz6ct2ObGpqAppSYkoFfbCS7NmIie7FdpkOtA6BUhN9iLZ7obLsx939bsaJ7QNjnt2LlqHQzNXQBOjhr1HZ2TfOwQJaYEJw2LEaEkELDX5cFsp8gpL8dzseejQNgNZ6TZkpMYjJckrRhUXHPFVsCeWo8qzB//TYwjOPfY8dWaMGEcmUsXSubxza4yd9gni0jKRlJaKhCQH4m12aZdoupNK/M1yZGL+z7Oxp7T5I7x05s+fL2MwuGiPwUJcycrFeMz3xAwcOoyc48rUpoDLs7lg0giDlbgc/HCBUXt/+tOfVKlpYUb9FSsCH73He8E0po2FK4b5mzc3AQJCDr1wMzKzsuC1JyNBGOqME/DHChjduHFolZSBl7+6H5sL6x+oHw169eolczsxboBpKfmcQQbfmMM0ucqWS8CbAsZXMJDI+JwRrnZlQFG04XsYYzYihXErXKnc0Gzz9YGrms1hsVzRbExC11AoeMboxeYiSEAciQmYd+15KPIA1VS++KPUKGEK/k5iSMlKzcW8TU/jgLP58xa1a9dOjhyMueDy7TPOOEMmH2NvaYxEYwQdl1vzCUfshUIlS2a8AXNdMTFBpHlm2WD5vsb4C462VnMkXMJN4WUwEOMgzDDiT49x4bJvhvPq2i8/D/Pq8rrsBCKNjWAWEsaM8xx+dyvmzZsnR1iuVuZn4KMOzPCeMf6FS9EZh8/gK6tOhyGx5lxbp556akCHpfPmm2/K4CjGeoR6wi9/My6nZwfI4C5zhGFzECQg5PisNHw/fICcMORy91BQdlJsWZi57iZsLwoMMW1O2PhC3WQ2Kj63kPERDFBibAGzZhhhdB2TolEdoEDl5OTIRloXDDLiCMYIPD3GwqqXZ+wIGw4TvDEslUnTGAprhKqZHg/CuAn2vPq1OIvPz06BYZBTpI9WZlYQhrYyBSpjOawSQL/zzjtSVaUAMb7l9ttvl9/fCN975MiRsp73mdfh940kYRwnVo1Jsgm/JwWO2WaYPolhAwZTWMLvzmz8zI7PlD+zZs0KykDfLNBID8XW4lLtvLfe1f53zvvaLR9P0+6aP1n7/wsnauMXP649tuQf2nNf3KlN+nKk9sbXV2ivr+mjHXRuUWc2L6KBaqJXVaVAOnbsqL399tuqpGn9+vULeBYGn4HB2yB6aa20tFTz+Xza8OHDtUsvvVQdEZquXbtqc+bMkdtCsDTRs8rnYgihlHU6o0aNks8lIUzEXKUSOwtbSdbpiIaqiRFJJqI2IwRDPjskUubOnSuf/6Hz1FNPaT179lSlWoSNFpSsW4yCAc/74HNLeI/WrFmjajRt9OjRmhgBVMkPE14LgVMlP2L00IRqpEqatnz5cnkt0alpYhSSdfzOQhjkNpkyZUrQZ+U5kydPVqXmw3IE0emc0QrTL78YJaIHDLf2iJEi9oRUzNl0rao5fOCwzB5ShyqHMVxVT2DAB3pSbaM6wMQB4UJpjXD0Iuxl+SQlPrKAo5AROg0YvceIRz45iWGsXLpizhbC2HE+T5wqjBkeS1UxUtjjM+KPKiMfzcBnNrLnZ8YVI7wm7TkjTKBgdD7o39F4HEeGcKlUQ6HbKFSZeA94v1lnfH4IR7shQ4aokh/+bvX5/tEirICQY9PT8dxFg1EqGpWXa1BCEB9nE68EfF8QOtfR74VR/aK6YlSD9CfdMjs6w0+pvjBzB4f0uhAdTI1qQBWKhqToqYP0cCZsYDgrBYXvwcZOITTmvmWDZKOggU+PnBk2ICv1zQraE1TFaBvRLmDcN4Wfn4PJFoywIzB6nvbu3SuzitDpoaPbVMyyqMO0PXXFvhP9/ujoqV8pXLwXTOtD7xTXuelQ/WTaIe4ntMGonkbaaUWTOgWEdBb65qTB14iRpDLoC9eiISmxFTYX1i+2PBrQYDRm2DDCfUYB4U03JnzgCEM3JBMxs3fXY7dDXc8IjVdj2hs+poCNyGy/0Pjl9dnAGZut69dG6A2jbULDlbm2zDm0GKPNXpfnmrOHmKG7lQ2YdgWNYD7sh0nrmOaT3ixjrimODrSheF3aPRQk2km8FzrsuemJ4qjE/TyWdpz50c7me03Y4Rh7fubZpfOAQqu/r/n7cATjMxE5EvM78z052tSV2KIpCEraEI7fDu7Gs5+/hZzUBCQlVCE5qRS2uEokJx4S0i0MR3Ept68S15++APbExrv2IoW9EX9QqwwZNCTZe+tJx+guZU9kztbBxs5eiteo69kZOhQsNlzz+7LeKgEDPwuFh8JiTGBAlY/fgUKiwzy3LBvj3jn6caTj97FKgKCzYcMGmYbHyuvDJ/zy/fXPzJ6b1xo/frw8j9fmfiO//fabVNeonjFxBEczq2fM89psyEYVk9+ZucLMvT9HKl6Xxr75oao6vI98T74XOzWOZM2dwKFeAkK2HizAC6smCSGxIyWpLEBAqACUuwpxwxmLkGwPHzwV4/CAah0bHZO2hYINlZ2GceT9byEiFctIlzYdcVvv4XC6SsWAYbJJhKjFCTtErnqM0SJgiiJmwA8HRwxmx/9vpN4jiM72om2Y8t14tE1NEiNIiVKxfEJo4nDdGQvkHEqMGC2dBrfiTlmdcVWP0Sj3iJFETbV7NQ/app0UE44YRwyNaskn5fbCoONHwOn2e22crn3okWudZjNGjJZIo7v609oPwKATHkRheR7O7DAcHdLPUntixGj5NNgGMbOjeBWOyax9YGWMGC0f4P8Am/rzRtwnICUAAAAASUVORK5CYII=">
                          </td>
                          </tr>
                      </table>
                    <!-- end HEADER-tags -->
                </div>
            </td>
         <td >
            <div style='mso-element:footer;' id=f1><span style='position:relative;z-index:-1;'>
                <!-- FOOTER-tags -->
                <p>
                <table style="border-top: 2px solid #ccc;" width="100%" cellpadding="0" cellspacing="0">
                      <tr style="color:gray">
                        DOCUMENT TITLE | 18 May 2018 | Confidential and Proprietary information. © 2018 Mphasis
                      </tr>
                </table>
                </p>    
                <!-- end FOOTER-tags -->
                <span style='mso-no-proof:yes'></span>
                  <p class=MsoFooter style="color:gray">
                    <span style=mso-tab-count:2'></span>
                      Page <span style='mso-field-code: PAGE '><span style='mso-no-proof:yes'></span> from <span style='mso-field-code: NUMPAGES '></span>
                    </span>
                  </p>
            </div>
            <div style='mso-element:header' id=fh1>
                <p class=MsoHeader><span lang=EN-US style='mso-ansi-language:EN-US'>&nbsp;<o:p></o:p></span></p>
                </div>
                <div style='mso-element:footer' id=ff1>
                <p class=MsoFooter><span lang=EN-US style='mso-ansi-language:EN-US'>&nbsp;<o:p></o:p></span></p>
            </div>
            <div style="border-bottom: 10px solid red;"></div>
          </td>
         </tr>
         
      </table>
       
     </div>
     </body></html>
     `;
    var footer = `<div>This is footer</div>`;
    var converted = htmlDocx.asBlob(content, {
      orientation: "landscape"
    });
    /*Current date and time */
    var today = new Date();
    let dd: any = today.getDate();
    let mm: any = today.getMonth() + 1; //January is 0!
    let yyyy = today.getFullYear();
    let hrs = today.getHours();
    let min = today.getMinutes();
    if (dd < 10) {
      dd = "0" + dd;
    }
    if (mm < 10) {
      mm = "0" + mm;
    }

    let dateandtime = " " + dd + "" + mm + "" + yyyy + " " + hrs + "" + min;
    saveAs(converted, dateandtime + ".docx");
  }
}
