import { Component, OnInit } from "@angular/core";
import { AuthService } from "../../components/auth/auth.service";
import { SharedService } from "../../services/shared.service";

@Component({
  selector: "app-header",
  templateUrl: "./header.component.html",
  styleUrls: ["./header.component.css"]
})
export class HeaderComponent implements OnInit {
  // toggle: boolean = false;
  loginUser: string;
  constructor(
    private authService: AuthService,
    private sharedService: SharedService
  ) {}

  ngOnInit() {
    this.sharedService.currentLoginUser.subscribe(res => {
      this.loginUser = res;
    });
  }

  logOut() {
    this.authService.logout();
  }
}
