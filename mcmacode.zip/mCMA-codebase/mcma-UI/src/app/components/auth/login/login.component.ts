import { Component, OnInit } from "@angular/core";
import { Router, NavigationExtras } from "@angular/router";
import { AuthService } from "../auth.service";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";

@Component({
  selector: "app-login",
  templateUrl: "./login.component.html",
  styleUrls: ["./login.component.css"]
})
export class LoginComponent implements OnInit {
  message: string;
  username: string;
  password: string;
  role: string;
  loginFormGroup: FormGroup;

  constructor(
    public authService: AuthService,
    public router: Router,
    private formBuilder: FormBuilder
  ) {
    // this.setMessage();
  }
  ngOnInit() {
    this.authService.currentMessage.subscribe(res =>
      console.log((this.message = res))
    );
    this.loginFormGroup = this.formBuilder.group({
      roleCtrl: [null, [Validators.required]],
      userNameCtrl: [null, [Validators.required, Validators.email]],
      passwordCtrl: [null, [Validators.required]]
    });
  }
  // setMessage() {
  //   this.message = "Logged " + (this.authService.isLoggedIn ? "in" : "out");
  // }

  //login1() {
  //   this.authService.login().subscribe(() => {
  //     this.setMessage();
  //     if (this.authService.isLoggedIn) {
  //       // Get the redirect URL from our auth service
  //       // If no redirect has been set, use the default
  //       let redirect = this.authService.redirectUrl
  //         ? this.router.parseUrl(this.authService.redirectUrl)
  //         : "/admin";
  //       // Set our navigation extras object
  //       // that passes on our global query params and fragment
  //       let navigationExtras: NavigationExtras = {
  //         queryParamsHandling: "preserve",
  //         preserveFragment: true
  //       };
  //       // Redirect the user
  //       this.router.navigateByUrl(redirect, navigationExtras);
  //     }
  //   });
  //}
  login() {
    // this.message = "Trying to log in ...";

    let data = {
      email: this.username,
      password: this.password,
      loginRole: this.role
    };
    this.authService.login(data);
    this.authService.setUserName(this.username);
  }

  logout() {
    this.authService.logout();
    // this.setMessage();
  }
}
