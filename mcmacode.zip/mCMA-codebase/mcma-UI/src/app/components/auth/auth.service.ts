import { Injectable } from "@angular/core";
import { SharedService } from "../../services/shared.service";
import { Router, NavigationExtras } from "@angular/router";

import { Observable, of, BehaviorSubject } from "rxjs";
import { tap, delay } from "rxjs/operators";

@Injectable({
  providedIn: "root"
})
export class AuthService {
  isLoggedIn = false;
  userName = new BehaviorSubject("");
  currentUserName = this.userName.asObservable();
  message = new BehaviorSubject("");
  currentMessage = this.message.asObservable();
  role = new BehaviorSubject("");
  currentRole = this.role.asObservable();

  // store the URL so we can redirect after logging in
  redirectUrl: string;

  constructor(
    public router: Router,
    private sharedService: SharedService
  ) {}
  login(data) {
    this.sharedService
      .loginVerification(data)
      .subscribe((res: any) => {
        this.message.next(res.status);
        if (res.status == "User verified") {
          this.isLoggedIn = true;
          this.sharedService.loginVerified.next(true);
          this.role.next(res.role);
          this.sharedService.loginUser.next(
            res.customer_name
          );
          if (res.role == "admin") {
            this.router.navigate(["/admin"]);
          } else {
            this.sharedService.customerId.next(
              res.customer_id
            );
            this.router.navigate(["/customer"]);
          }
        }
      });
    // return of(true).pipe(
    //   delay(1000),
    //   tap(val => (this.isLoggedIn = true))
    // );
  }

  logout(): void {
    this.isLoggedIn = false;
    this.message.next("");
    this.sharedService.loginVerified.next(false);
    this.router.navigate(["/"]);
  }

  setUserName(userName) {
    this.userName.next(userName);
  }
}
