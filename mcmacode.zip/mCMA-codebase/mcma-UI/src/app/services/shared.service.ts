import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders, HttpRequest } from "@angular/common/http";
import { Observable, of, BehaviorSubject } from "rxjs";
import { map, tap, catchError } from "rxjs/operators";
import { environment } from "../../environments/environment";

@Injectable({
  providedIn: "root"
})
export class SharedService {
  apiUrl = environment.apiUrl;
  loginVerified = new BehaviorSubject(false);
  currentLoginStatus = this.loginVerified.asObservable();
  customerId = new BehaviorSubject(null);
  currentCustomerId = this.customerId.asObservable();

  loginUser = new BehaviorSubject(null);
  currentLoginUser = this.loginUser.asObservable();

  constructor(private http: HttpClient) {}
  loginVerification(data) {
    return this.http
      .post(this.apiUrl + "userLogin", data)
      .pipe(tap(res => res));
  }
  getAdminData() {
    return this.http.get(this.apiUrl + "createadmin").pipe(
      tap(res => {
        console.log(res);
      })
    );
  }
  postAdminData(data) {
    return this.http.post(this.apiUrl + "createadmin", data).pipe(
      tap(res => {
        console.log(res);
      })
    );
  }
  getCustomerData() {
    return this.http.get(this.apiUrl + "createuser").pipe(
      tap(res => {
        console.log(res);
      })
    );
  }
  getTemplateData(assessmentId) {
    return this.http
      .get(
        this.apiUrl + "gettemplate?assessment_id=" + assessmentId
      )
      .pipe(
        tap(res => {
          console.log(res);
        })
      );
  }
  getReportData(assessmentId, customerId) {
    return this.http
      .get(
        this.apiUrl + "getAppReport?assessment_id=" +
          assessmentId +
          "&customer_id=" +
          customerId
      )
      .pipe(
        tap(res => {
          console.log(res);
        })
      );
  }
  getCountriesList() {
    return this.http.get(this.apiUrl + "getcountries").pipe(
      tap(res => {
        console.log(res);
      })
    );
  }
  postCustomerData(data) {
    return this.http.post(this.apiUrl + "createuser", data).pipe(
      tap(res => {
        console.log(res);
      })
    );
  }

  sendMail(mail) {
    return this.http.get(this.apiUrl + "sendmail/" + mail).pipe(
      tap(res => {
        console.log(res);
      })
    );
  }
  getAssessmentDetails(data) {
    return this.http
      .get(this.apiUrl + "getassessments/" + data)
      .pipe(
        tap(res => {
          console.log(res);
        })
      );
  }
  postNewAssessmentData(data) {
    return this.http
      .post(this.apiUrl + "createassesment", data)
      .pipe(
        tap(res => {
          console.log(res);
        })
      );
  }
  postCSVFile(data, assessmentId) {
    const headers = new HttpHeaders().set(
      "Content-type",
      "multipart/form-data"
    );
    return this.http
      .post(this.apiUrl + "uploadQuestion/" + assessmentId, data)
      .pipe(tap(res => res));
  }
  postQuestionRevisedResponse(data, assessmentId) {
    const headers = new HttpHeaders().set(
      "Content-type",
      "multipart/form-data"
    );
    return this.http
      .post(
        this.apiUrl + "update_assessment/" + assessmentId,
        data
      )
      .pipe(tap(res => res));
  }
  getApplicationScoreData(customerId, assessmentId) {
    return this.http
      .get(
        this.apiUrl + "getAppAssessment?assessment_id=" +
          assessmentId +
          "&customer_id=" +
          customerId
      )
      .pipe(
        tap(res => {
          console.log(res);
        })
      );
  }
  getQuestionsData(assessmentId) {
    return this.http
      .get(this.apiUrl + "getquestions/" + assessmentId)
      .pipe(
        tap(res => {
          console.log(res);
        })
      );
  }
  postCustomerResponseAsCSV(data, assessmentId, customerId) {
    const headers = new HttpHeaders().set(
      "Content-type",
      "multipart/form-data"
    );
    return this.http
      .post(
        this.apiUrl + "csvtojson?assessment_id=" +
          assessmentId +
          "&customer_id=" +
          customerId,
        data
      )
      .pipe(tap(res => res));
  }

  getQuestionRevisedResponse(customerId, assessmentId) {
    return this.http
      .get(
        this.apiUrl + "getSavedAssessment?assessment_id=" +
          assessmentId +
          "&customer_id=" +
          customerId
      )
      .pipe(
        tap(res => {
          console.log(res);
        })
      );
  }
  postCustomerRevisedResponse(data, assessmentId, customerId, status) {
    console.log(data, "dfsasfaf");
    return this.http
      .post(
        this.apiUrl + "performAssessment?assessment_id=" +
          assessmentId +
          "&customer_id=" +
          customerId +
          "&status=" +
          status,
        data
      )
      .pipe(tap(res => res));
  }
  postChangePasswordDetails(data) {
    console.log(data, "dfsasfaf");
    return this.http
      .post(this.apiUrl + "changePassword", data)
      .pipe(tap(res => res));
  }
  getReportDetails(customerId, assessmentId) {
    return this.http
      .get(
        this.apiUrl + "getReport?assessment_id=" +
          assessmentId +
          "&customer_id=" +
          customerId
      )
      .pipe(tap(res => res));
  }
  deleteAssessment(customerId, assessmentId) {
    if (confirm("Are you want to delete assessment?")) {
      return this.http
        .get(
          this.apiUrl + "deleteassessment?assessment_id=" +
            assessmentId +
            "&customer_id=" +
            customerId
        )
        .pipe(tap(res => res));
    }
  }
}
