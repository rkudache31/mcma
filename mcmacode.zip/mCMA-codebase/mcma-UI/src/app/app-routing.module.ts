import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { AdminComponent } from "./components/admin/admin.component";
import { ChangePasswordComponent } from "./components/change-password/change-password.component";
import { CustomerComponent } from "./components/customer/customer.component";
import { AuthGuard } from "./components/auth/auth.guard";

const routes: Routes = [
  {
    path: "admin",
    component: AdminComponent,
    canActivate: [AuthGuard]
  },
  { path: "customer", component: CustomerComponent, canActivate: [AuthGuard] },
  // { path: "customer", component: CustomerComponent },
  {
    path: "change-password",
    component: ChangePasswordComponent,
    canActivate: [AuthGuard]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
  declarations: []
})
export class AppRoutingModule {}

export const RoutingComponents = [
  AdminComponent,
  ChangePasswordComponent,
  CustomerComponent
];
