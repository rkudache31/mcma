import { BrowserModule } from "@angular/platform-browser";
import { NgModule } from "@angular/core";

import { AppRoutingModule, RoutingComponents } from "./app-routing.module";
import { AppComponent } from "./app.component";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { AngularMaterialModule } from "./angular-material.module";
import { AuthModule } from "./components/auth/auth.module";
import { ChartsModule } from "ng2-charts";

import { HeaderComponent } from "./components/header/header.component";
import { FooterComponent } from "./components/footer/footer.component";
import { HttpClientModule } from "@angular/common/http";
import { CustomerDetailsPipe } from "./components/admin/customer-details.pipe";
import { FilterAssessmentDetailsPipe } from "./components/admin/filter-assessment-details.pipe";

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    RoutingComponents,
    FooterComponent,
    CustomerDetailsPipe,
    FilterAssessmentDetailsPipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    AngularMaterialModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    AuthModule,
    ChartsModule,
    ReactiveFormsModule.withConfig({warnOnNgModelWithFormControl: 'never'})
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule {}
